﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using WatchStore.Areas.Admin.Models;
using WatchStore.Models;

namespace WatchStore.Areas.Admin.Controllers
{
    public class AuthhController : Controller
    {
        dbQLBandhDataContext db = new dbQLBandhDataContext();

        // GET: Admin/Authh

       
        public ActionResult kCoQuyen()
        {
            return View();
        }

       /* private string GetRandomText()
        {
            StringBuilder randomText = new StringBuilder();
            string alphabets = "012345679ACEFGHKLMNPRSWXZabcdefghijkhlmnopqrstuvwxyz";
            Random r = new Random();
            for (int j = 0; j <= 5; j++)
            {
                randomText.Append(alphabets[r.Next(alphabets.Length)]);
            }
            return randomText.ToString();
        }
        public FileResult GetCaptchaImage()
        {
            string text = Session["CAPTCHA"].ToString();

            //first, create a dummy bitmap just to get a graphics object
            Image img = new Bitmap(1, 1);
            Graphics drawing = Graphics.FromImage(img);

            Font font = new Font("Arial", 15);
            //measure the string to see how big the image needs to be
            SizeF textSize = drawing.MeasureString(text, font);

            //free up the dummy image and old graphics object
            img.Dispose();
            drawing.Dispose();

            //create a new image of the right size
            img = new Bitmap((int)textSize.Width + 40, (int)textSize.Height + 20);
            drawing = Graphics.FromImage(img);

            Color backColor = Color.Black;
            Color textColor = Color.White;
            //paint the background
            drawing.Clear(backColor);

            //create a brush for the text
            Brush textBrush = new SolidBrush(textColor);

            drawing.DrawString(text, font, textBrush, 20, 10);

            drawing.Save();

            font.Dispose();
            textBrush.Dispose();
            drawing.Dispose();

            MemoryStream ms = new MemoryStream();
            img.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
            img.Dispose();

            return File(ms.ToArray(), "image/png");
        }
        */
        [HttpGet]
        public ActionResult Login()
        {
           // Session["CAPTCHA"] = GetRandomText();
            return View();
        }
        [HttpPost]
        public ActionResult Login(FormCollection f, LoginViewModel model)
        {
           
            var TK = f["username"];
            var MK = f["password"];
            var ad = db.ADMINs.SingleOrDefault(n => n.UserAdmin == TK && n.PassAdmin  == MK);
            if (ad != null)
            {
                /*string cap = Session["CAPTCHA"].ToString();
                if (!model.Captcha.Equals(cap))
                {
                    ViewBag.CaptchaError = "Nhập sai";
                    Session["CAPTCHA"] = GetRandomText();
                    return View(model);
                }*/
                ViewBag.ThongBao = "Xin chào, Admin:" + ad.Hoten;
                FormsAuthentication.SetAuthCookie(ad.Hoten, false);
                Session["TaiKhoanAdmin"] = ad;
                Session["Admin"] = ad.UserAdmin;
                Session["Pw"] = ad.PassAdmin;
                return RedirectToAction("Index", "ThongKe");
            }
            ViewBag.ThongBao = "Tên tài khoản hoặc mật khẩu không đúng!!!";
            TempData["thongbao"] = "Không tìm thấy khách hàng nào phù hợp.";
            return View();
        }
        public ActionResult Logout()
        {
            Session.Abandon();
            FormsAuthentication.SignOut();
            return RedirectToAction("Login");
        }

    }
}